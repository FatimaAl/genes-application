#ifndef CODONS_H
#define CODONS_H


class Codons
{
    public:
        Codons();
        virtual ~Codons();
        void Set_codon();
        Codon Get_codon();
        void LoadCodonFromFile();


    protected:

    private:
        Codon* Codons[];
};

#endif // CODONS_H
