#ifndef DNA _H
#define DNA _H
#include "GenesApplication.h"

template <class D_type>
class DNA : public GenesApplication
{
    public:
        DNA ();
        virtual ~DNA ();
        RNA Convert_to_RNA();
        void Get_Complement_Strands();
        void Find_Defects();
        void Display_DNA(); ///display the choice of the user

    protected:

    private:
        D_type DNA_Type;
};

#endif // DNA _H
