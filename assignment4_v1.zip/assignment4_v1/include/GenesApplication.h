#ifndef GENESAPPLICATION_H
#define GENESAPPLICATION_H


class GenesApplication
{
    public:
        GenesApplication();
        virtual ~GenesApplication();
        void Menu();/// display the menu to the user to choose what s/he want from the program
        void LCS(); ///to find how much 2 sequances are alike


    protected:
        char* Sequance;

    private:
};

#endif // GENESAPPLICATION_H
