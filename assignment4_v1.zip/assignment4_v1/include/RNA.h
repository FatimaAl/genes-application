#ifndef RNA_H
#define RNA_H

template <class R-type >

class RNA
{
    public:
        RNA();
        virtual ~RNA();
        Protein Convert_to_Protein(codons);

    protected:

    private:
        R_type RNAType;
};

#endif // RNA_H
