#ifndef PROTEIN_H
#define PROTEIN_H

template < class P_type >

class protein
{
    public:
        protein();
        virtual ~protein();

    protected:

    private:
        P_type ProteinType;
};

#endif // PROTEIN_H
