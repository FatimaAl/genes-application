#include <iostream>

using namespace std;


struct Codon
{
    char AminoAcid;
    char Data[3];
};


int main()
{

    return 0;
}
