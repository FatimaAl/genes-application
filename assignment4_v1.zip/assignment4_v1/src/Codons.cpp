#include "Codons.h"

Codons::Codons()
{
    //ctor
}

Codons::~Codons()
{
    //dtor
}
