#include "DNA .h"

DNA ::DNA ()
{
    //ctor
}

DNA ::~DNA ()
{
    //dtor
}

void DNA :: Get_Complement_Strands()
{
    D_type* CompStrand;
    CompStrand = new D_type[Sequance.size()];
    for (int i=0; i<CompStrand.size(); i++)
    {
        if (Sequance[i]=='T')
        {
            CompStrand[i]='A';
        }
        else if (Sequance[i]=='A')
        {
            CompStrand[i]='T';
        }
        else if (Sequance[i]=='C')
        {
            CompStrand[i]='G';
        }
        else if (Sequance[i]=='G')
        {
            CompStrand[i]='C';
        }
        else
        {
            cout << "This sequance is DEFECT \n"
        }

    }

}

bool DNA :: Find_Defects()
{
    for (int i=0 ; i<Sequance.size() ; i++ )
    {
        if (Sequance[i] != 'A' || Sequance[i] != 'T' || Sequance[i] != 'G' || Sequance[i] != 'C')
        {
            return true;
        }
        else
        {
            return false;
        }
    }
}

void DNA :: Display_DNA()
{
    for (int i=0 ;i<Sequance.size() ; i++)
    {
        cout << Sequance[i];
    }
}

RNA DNA :: Convert_to_RNA()
{
    R_type* RNASequance;
    for (int i=0 ; i<Sequance.size() ; i++ )
    {
        if (Sequance[i]=='T')
        {
            RNASequance[i]='U';
        }
        else
        {
            RNASequance[i]=Sequance[i];
        }
    }
    return RNASequance;
}
