#include "GenesApplication.h"

GenesApplication::GenesApplication(string s)
{
    for (int i=0 ; i<s.size ;i++)
    {
        Sequance[i]=s[i];
    }
    //ctor
}

GenesApplication::~GenesApplication()
{
    delete Sequance;
    Sequance=nullptr;
    //dtor
}

void GenesApplication::Menu()
{
    int choice=1;
    while (choice!=0)
    {
        cout << "Welcome to Genes Application \n";
        cout << "Please enter the number of the operation you want to do \n";
        cout << "1_Convert from DNA to RNA \n" << "2_Convert from DNA to Protein \n" << "3_Convert from RNA to protein" <<"4_LCS operation \n" << "0_close the program \n";
        cin >> choice;
        if (choice==1)
        {

        }
        else if (choice==2)
        {

        }
        else if (choice==3)
        {

        }
        else if (choice==4)
        {

        }
    }
}
