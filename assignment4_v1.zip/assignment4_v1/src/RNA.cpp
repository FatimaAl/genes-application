#include "RNA.h"

RNA::RNA()
{
    //ctor
}

RNA::~RNA()
{
    //dtor
}

Protein  RNA :: Convert_to_Protein(codons)
{

}
