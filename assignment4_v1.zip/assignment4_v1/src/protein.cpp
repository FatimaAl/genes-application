#include "protein.h"

protein::protein()
{
    //ctor
}

protein::~protein()
{
    //dtor
}
